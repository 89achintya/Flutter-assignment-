
import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const baseUrl = 'https://dummyjson.com';

  Future<List<dynamic>> fetchUsers({int limit = 10, int skip = 0}) async {
    final response = await http.get(Uri.parse('\$baseUrl/users?limit=\$limit&skip=\$skip'));
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['users'];
    } else {
      throw Exception('Failed to load users');
    }
  }
}
