
# Flutter Assessment Task – Internship Submission

## 📱 App Overview

This app is built using Flutter with `flutter_bloc` for state management. It integrates with the DummyJSON API to:

- Display a paginated user list with infinite scroll
- Provide a search bar to filter users by name
- Show user details including posts and todos
- Allow creating a new post locally

## 🔧 Features Implemented

- User list screen (mock UI)
- Real-time search bar (mock)
- User detail screen with dummy posts and todos
- Create post screen (local only)
- BLoC setup with loading/success/error states
- API service file with integration points

## 🔗 API Endpoints Used

- Users: https://dummyjson.com/users
- Posts: https://dummyjson.com/posts/user/{userId}
- Todos: https://dummyjson.com/todos/user/{userId}

## 🧠 Architecture

- `flutter_bloc` for state management
- Clean folder structure:
  ```
  lib/
  ├── blocs/
  ├── models/
  ├── screens/
  ├── services/
  └── main.dart
  ```

## ⚠️ Notes

Due to hardware limitations (no laptop), full app code could not be completed. However, this submission includes:
- Clean project structure
- Dart code files showing logic understanding
- UI flow documentation

## 🙏 Thank You

I look forward to learning and growing through this opportunity!
