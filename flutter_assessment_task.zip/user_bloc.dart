
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

// Events
abstract class UserEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class FetchUsers extends UserEvent {}

class SearchUsers extends UserEvent {
  final String query;
  SearchUsers(this.query);

  @override
  List<Object> get props => [query];
}

// States
abstract class UserState extends Equatable {
  @override
  List<Object> get props => [];
}

class UserLoading extends UserState {}

class UserLoaded extends UserState {
  final List<String> users; // mock data
  UserLoaded(this.users);

  @override
  List<Object> get props => [users];
}

class UserError extends UserState {
  final String message;
  UserError(this.message);

  @override
  List<Object> get props => [message];
}

// Bloc
class UserBloc extends Bloc<UserEvent, UserState> {
  UserBloc() : super(UserLoading()) {
    on<FetchUsers>((event, emit) async {
      emit(UserLoading());
      await Future.delayed(Duration(seconds: 2)); // simulate API
      emit(UserLoaded(['John', 'Jane', 'Alice']));
    });

    on<SearchUsers>((event, emit) {
      final results = ['John', 'Jane', 'Alice']
          .where((user) => user.toLowerCase().contains(event.query.toLowerCase()))
          .toList();
      emit(UserLoaded(results));
    });
  }
}
